export class ApplyLoan{
    id:number;
    accountNumber:string = '';
    loanType:string = '';
    loanAmount:String = '';
    status:string = '';
    date:string = '';
}